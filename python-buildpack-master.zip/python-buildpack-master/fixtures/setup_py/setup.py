from setuptools import setup

setup(
    name="my-app",
    version="1.0.0",
    long_description="sample setup.py",
    packages=['funniest'],
    include_package_data=True,
    zip_safe=False,
)
