def joke():
    return 'Knock Knock. Who is there?'
