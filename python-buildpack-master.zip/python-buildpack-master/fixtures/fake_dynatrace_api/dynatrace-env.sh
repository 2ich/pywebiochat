#!/bin/bash

export DT_HELLO=some-value
